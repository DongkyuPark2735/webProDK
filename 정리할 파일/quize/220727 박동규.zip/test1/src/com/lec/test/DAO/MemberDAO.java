package com.lec.test.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.lec.test.DTO.MemberDTO;

public class MemberDAO {
	
	private static MemberDAO INSTANCE;
	
	public static MemberDAO getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new MemberDAO();
		}
		return INSTANCE;
	}
	
	
	public static Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xe", "scott","tiger");
		return con;
	}
	// 회원 리스트
	public ArrayList<MemberDTO> memberList(){
		ArrayList<MemberDTO> mlist = new ArrayList<MemberDTO>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM MEMBER ORDER BY CUSTNO";

		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int custno = rs.getInt("custno");
				String custname = rs.getString("custname");
				String phone= rs.getString("phone");
				String address= rs.getString("address");
				Date joindate= rs.getDate("joindate");
				String grade= rs.getString("grade");
				String city= rs.getString("city");
				mlist.add(new MemberDTO(custno, custname, phone, address, joindate, grade, city));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(con!=null) con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return mlist;
	}
	
	// 회원등록
	public int insertMember(MemberDTO mdto){
		Connection con = null;
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "INSERT INTO MEMBER VALUES " + 
				"	(MEMBER_SQ.NEXTVAL, ?, ?, ?, ?, ?, ?)";
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mdto.getCustname());
			pstmt.setString(2, mdto.getPhone());
			pstmt.setString(3, mdto.getAddress());
			pstmt.setDate(4, mdto.getJoindate());
			pstmt.setString(5, mdto.getGrade());
			pstmt.setString(6, mdto.getCity());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(pstmt!=null) pstmt.close();
				if(con!=null) con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return result;
	}
	
	// 회원 dto 상세	
	public MemberDTO detailMember(int custno){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MemberDTO mdto = null;
		String sql = "SELECT * FROM MEMBER WHERE CUSTNO = ?";
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, custno);
			rs = pstmt.executeQuery();
			rs.next();
			String custname = rs.getString("custname");
			String phone= rs.getString("phone");
			String address= rs.getString("address");
			Date joindate= rs.getDate("joindate");
			String grade= rs.getString("grade");
			String city= rs.getString("city");
			mdto = new MemberDTO(custno, custname, phone, address, joindate, grade, city);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(con!=null) con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return mdto;
	}
	
	//회원 수정
	public int updateMember(MemberDTO mdto){
		Connection con = null;
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "UPDATE MEMBER SET CUSTNAME = ?, " + 
				" PHONE = ?," + 
				" ADDRESS = ?," + 
				" JOINDATE = ?," + 
				" GRADE = ?," + 
				" CITY = ?" + 
				" WHERE CUSTNO = ?";
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mdto.getCustname());
			pstmt.setString(2, mdto.getPhone());
			pstmt.setString(3, mdto.getAddress());
			pstmt.setDate(4, mdto.getJoindate());
			pstmt.setString(5, mdto.getGrade());
			pstmt.setString(6, mdto.getCity());
			pstmt.setInt(7, mdto.getCustno());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(pstmt!=null) pstmt.close();
				if(con!=null) con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return result;
	}
	
	// 회원 번호가져오기
	public int memberNum(){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		String sql = "SELECT CUSTNO FROM MEMBER ORDER BY CUSTNO DESC";

		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			result = rs.getInt("custno");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(con!=null) con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return result;
	}
	
}

















