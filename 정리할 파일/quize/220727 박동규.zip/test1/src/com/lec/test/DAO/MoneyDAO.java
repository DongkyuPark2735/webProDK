package com.lec.test.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.lec.test.DTO.MemberDTO;
import com.lec.test.DTO.MoneyDTO;

public class MoneyDAO {

	private static MoneyDAO INSTANCE;
	
	public static MoneyDAO getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new MoneyDAO();
		}
		return INSTANCE;
	}
	
	public static Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xe", "scott","tiger");
		return con;
	}
	
	// 제품 매출 조회 리스트
	public ArrayList<MoneyDTO> moneyList(){
		ArrayList<MoneyDTO> mlist = new ArrayList<MoneyDTO>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT PCODE, SUM(PRICE) SP FROM MONEY" + 
				"	GROUP BY PCODE ORDER BY SP DESC";
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				String pcode = rs.getString("pcode");
				int sumPrice = rs.getInt("sp");
				MoneyDTO mdto = new MoneyDTO();
				mdto.setPcode(pcode);
				mdto.setPrice(sumPrice);
				mlist.add(mdto);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(con!=null) con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return mlist;
	}
	
	//회원매출조회
	public ArrayList<MemberDTO> memeberPriceList(){
		ArrayList<MemberDTO> mlist = new ArrayList<MemberDTO>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT ME.CUSTNO, ME.CUSTNAME, GR.GRADENAME, MO.SP " + 
				"	FROM MEMBER ME, " + 
				"		(SELECT CUSTNO,SUM(PRICE) SP FROM MONEY " + 
				"				GROUP BY CUSTNO ORDER BY SP DESC)MO, GRADETABLE GR " + 
				"		WHERE ME.CUSTNO = MO.CUSTNO AND ME.GRADE = GR.GRADE";
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int custno = rs.getInt("custno");
				String custname = rs.getString("custname");
				String gradeName = rs.getString("gradeName");
				int sumPrice = rs.getInt("sp");
				MemberDTO mdto = new MemberDTO();
				mdto.setCustno(custno);
				mdto.setCustname(custname);
				mdto.setGrade(gradeName);
				mdto.setPhone(String.valueOf(sumPrice));
				mlist.add(mdto);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(con!=null) con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return mlist;
	}
	
}
